<template>
 <v-container style="background-color:white">
   <Entidades />
 </v-container>
</template>

<script>
import Entidades from '@/components/Entidades'
export default {
 components: {
   Entidades
 }
}
</script>