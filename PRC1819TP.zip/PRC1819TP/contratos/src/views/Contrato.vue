<template>
 <v-container style="background-color:white">
   <Contrato :ent="$route.params.id"/>
 </v-container>
</template>

<script>
import Contrato from '@/components/Contrato'
export default {
 components: {
   Contrato
 }
}
</script>