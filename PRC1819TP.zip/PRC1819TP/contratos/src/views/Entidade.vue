<template>
 <v-container style="background-color:white">
   <Entidade :ent="$route.params.id"/>
 </v-container>
</template>

<script>
import Entidade from '@/components/Entidade'
export default {
 components: {
   Entidade
 }
}
</script>