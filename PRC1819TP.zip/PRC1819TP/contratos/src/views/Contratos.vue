<template>
 <v-container style="background-color:white">
   <Contrato />
 </v-container>
</template>

<script>
import Contrato from '@/components/Contratos'
export default {
 components: {
   Contrato
 }
}
</script>