import Vue from 'vue'
import Router from 'vue-router'
import Contrato from './views/Contrato'
import Entidade from './views/Entidade'
import Contratos from './views/Contratos'
import Entidades from './views/Entidades'

Vue.use(Router)

export default new Router({
  mode: 'history',
  base: process.env.BASE_URL,
  routes: [
    {
      path: '/contratos',
      name: 'contratos',
      // route level code-splitting
      // this generates a separate chunk (about.[hash].js) for this route
      // which is lazy-loaded when the route is visited.
      component: () => import(/* webpackChunkName: "about" */ './views/Contratos.vue')
    },
    {
      path: '/entidades/:id',
      name: 'entidade',
      component: () => import('./views/Entidade.vue')
    },
    {
      path: '/contratos/:id',
      name: 'contrato',
      component: () => import('./views/Contrato.vue')
    },
    {path: '/entidades',
     name: 'entidades',
     component: () => import('./views/Entidades.vue')
      }
  ]
})
