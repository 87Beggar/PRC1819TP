<template>
  <v-container>
      <v-flex xs2>
        <h3>Contratos</h3>
      </v-flex>
      <v-flex xs10>
        <v-data-table
        :headers="headers"
        :items="contratos"
        class="elevation-1"
        >
          <template v-slot:items="props">
            <tr>
              <td class="subheading">{{ props.item.entidade.split('#')[1] }}</td>
              <td class="subheading">{{ props.item.nome }}</td>
            </tr>
          </template>
        </v-data-table>
      </v-flex>
      <v-layout>
      <v-btn @click="goBack()" color="info">Voltar à página anterior</v-btn>
    </v-layout>
      <v-layout>
      <v-btn @click="goContratos()" color="info">Ir para contratos</v-btn>
    </v-layout>
  </v-container>
</template>

<script>
import axios from 'axios'
const lhost = 'http://localhost:8787'

export default {
  data: () => ({
    headers: [
      { text: 'Identificador', align: 'left', sortable: true, value: 'entidade', class: 'title' },
      { text: 'Nome da Entidade', align: 'left', sortable: true, value: 'nome', class: 'title' },
    ],
    contratos: []
  }),
  mounted: async function () {
    try {
      var response = await axios.get(lhost + '/entidades/')
      this.contratos = response.data
      console.log(contratos)
    } catch (e) {
      return (e)
    }
  },
  methods: {
    goBack: function () {
      this.$router.go(-1)
    },
    goContratos: function () {
      this.$router.push("/contratos")
    }
  }
}

</script>

<style>

</style>
