<template>
  <v-container>
      <v-flex xs2>
        <h3>Contratos</h3>
      </v-flex>
      <v-flex xs10>
        <v-data-table
        :headers="headers"
        :items="contratos"
        class="elevation-1"
        >
          <template v-slot:items="props">
            <tr>
              <td @click="goToContrato(props.item.contrato.split('#')[1])" class="subheading">{{ props.item.contrato.split('#')[1] }}</td>
              <td class="subheading">{{ props.item.objeto }}</td>
              <td class="subheading">{{ props.item.preco }}</td>
              <td @click="goToEnt(props.item.eAdjudicante.split('#')[1])" class="subheading">{{ props.item.eAdjudicante.split('#')[1] }}</td>
              <td @click="goToEnt(props.item.eAdjudicataria.split('#')[1])" class="subheading"> {{ props.item.eAdjudicataria.split('#')[1] }}</td>
            </tr>
          </template>
        </v-data-table>
      </v-flex>
      <v-layout>
      <v-btn @click="goBack" color="info">Voltar à página anterior</v-btn>
    </v-layout>

      <v-layout>
      <v-btn @click="goEntidades" color="info">Entidades</v-btn>
    </v-layout>
  </v-container>
</template>

<script>
import axios from 'axios'
const lhost = 'http://localhost:8787'

export default {
  data: () => ({
    headers: [
      { text: 'Contrato', align: 'left', sortable: true, value: 'contrato', class: 'title' },
      { text: 'Objeto do Contrato', align: 'left', sortable: true, value: 'objeto', class: 'title' },
      { text: 'Preço Contratual', align: 'left', sortable: true, value: 'preco', class: 'title' },
      { text: 'Entidade Adjudicante', align: 'left', sortable: true, value: 'eAdjudicante', class: 'title' },
      { text: 'Entidade Adjudicatária', align: 'left', sortable: true, value: 'eAdjudicataria', class: 'title' }
    ],
    contratos: []
  }),
  mounted: async function () {
    try {
      var response = await axios.get(lhost + '/contratos/')
      this.contratos = response.data
    } catch (e) {
      return (e)
    }
  },
  methods: {
    goToEnt: function (item) {
      this.$router.push('/entidades/' + item)
    },
    goBack: function () {
      this.$router.go(-1)
    },
    goEntidades: function () {
      this.$router.push('/entidades')
    }
  } 
}

</script>

<style>

</style>
