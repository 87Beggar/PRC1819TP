<template>
  <v-container>
      <v-flex xs2>
        <h3>Contrato</h3>
      </v-flex>
      <v-flex xs10>
        <v-data-table
        :headers="headers"
        :items="contratos"
        class="elevation-1"
        >
          <template v-slot:items="props">
            <tr>
              <td class="subheading">{{ props.item.objetoContrato }}</td>
              <td class="subheading">{{ props.item.precoContratual }}</td>
              <td class="subheading">{{ props.item.local }}</td>
              <td @click="goToEnt(props.item.adjudicante.split('#')[1])" class="subheading">{{ props.item.adjudicante.split('#')[1] }}</td>
              <td @click="goToEnt(props.item.adjudicataria.split('#')[1])" class="subheading">{{ props.item.adjudicataria.split('#')[1] }}</td>
              <td class="subheading">{{ props.item.precoEfetivo }}</td>
              <td class="subheading">{{ props.item.causasAlteracaoPrazo }}</td>
              <td class="subheading">{{ props.item.causasAlteracaoPreco }}</td>
              <td class="subheading">{{ props.item.estado }}</td>
              <td class="subheading">{{ props.item.numeroRegisto }}</td>
              <td class="subheading">{{ props.item.descricaoAcordo }}</td>
              <td class="subheading">{{ props.item.procedimentoCentralizado }}</td>
              <td class="subheading">{{ props.item.fechoContrato }}</td>
              <td class="subheading">{{ props.item.fundamentacao }}</td>
              <td class="subheading">{{ props.item.prazo }}</td>
              <td class="subheading">{{ props.item.dataPublicacao }}</td>
              <td class="subheading">{{ props.item.dataCelebracao }}</td>
              
              <td @click="goToEnt(props.item.colaboradores.split('#')[1])" class="subheading">{{ props.item.colaboradores.split('#')[1] }}</td>
            </tr>
          </template>
        </v-data-table>
      </v-flex>
      <v-layout>
      <v-btn @click="goBack" color="info">Voltar à página anterior</v-btn>
    </v-layout>
  </v-container>
</template>

<script>
import axios from 'axios'
const lhost = 'http://localhost:8787'

export default {
  props: ["ent"],
  data: () => ({
    headers: [
      { text: 'Objeto do Contrato', align: 'left', sortable: true, value: 'objetoContrato', class: 'title' },
      { text: 'Preço Contratual', align: 'left', sortable: true, value: 'precoContratual', class: 'title' },
      { text: 'Local de Execução', align: 'left', sortable: true, value: 'local', class: 'title' },
      { text: 'Entidade Adjudicante', align: 'left', sortable: true, value: 'adjudicante', class: 'title' },
      { text: 'Entidade Adjudicatária', align: 'left', sortable: true, value: 'adjudicataria', class: 'title' },
      { text: 'Preço Total Efetivo', align: 'left', sortable: true, value: 'precoEfetivo', class: 'title' },
      { text: 'Causas de Alterações de Prazo', align: 'left', sortable: true, value: 'causasAlteracaoPrazo', class: 'title' },
      { text: 'Causas de Alterações de Preço', align: 'left', sortable: true, value: 'causasAlteracaoPreco', class: 'title' },
      { text: 'Estado', align: 'left', sortable: true, value: 'estado', class: 'title' },
      { text: 'Número de Registo do Acordo Quadro', align: 'left', sortable: true, value: 'numeroRegisto', class: 'title' },
      { text: 'Descrição do Acordo Quadro', align: 'left', sortable: true, value: 'descricaoAcordo', class: 'title' },
      { text: 'Procedimento Centralizado', align: 'left', sortable: true, value: 'procedimentoCentralizado', class: 'title' },
      { text: 'Data de Fecho de Contrato', align: 'left', sortable: true, value: 'fechoContrato', class: 'title' },
      { text: 'Fundamentação', align: 'left', sortable: true, value: 'fundamentacao', class: 'title' },
      { text: 'Prazo de Execução', align: 'left', sortable: true, value: 'prazo', class: 'title' },
      { text: 'Data de Publicação', align: 'left', sortable: true, value: 'dataPublicacao', class: 'title' },
      { text: 'Data de celebração do contrato', align: 'left', sortable: true, value: 'dataCelebracao', class: 'title' },
      { text: 'CPV', align: 'left', sortable: true, value: 'cpv', class: 'title' }
      
    ],
    contratos: []
  }),
  mounted: async function () {
    try {
      var response = await axios.get(lhost + '/contratos/' + this.ent)
      this.contratos = response.data
      console.log(this.contratos)
    } catch (e) {
      console.log(e)
      return (e)
    }
  },
  methods: {
    goToCont: function (item) {
      this.$router.push('/contratos/' + item)
    },
    goBack: function () {
      this.$router.go(-1)
    },
    goToEnt: function (item) {
      this.$router.push('/entidades/' + item)
    }
  } 
}

</script>

<style>

</style>
