<template>
  <v-container>
      <v-flex xs2>
        <h3>Entidade</h3>
      </v-flex>
      <v-flex xs10>
        <v-data-table
        :headers="headers"
        :items="contratos"
        class="elevation-1"
        >
          <template v-slot:items="props">
            <tr>
              <td class="subheading">{{ props.item.n }}</td>
              <td @click="goToEnt(props.item.colaboradores.split('#')[1])" class="subheading">{{ props.item.colaboradores.split('#')[1] }}</td>
            </tr>
          </template>
        </v-data-table>
      </v-flex>
      <v-layout>
      <v-btn @click="goBack" color="info">Voltar à página anterior</v-btn>
    </v-layout>
  </v-container>
</template>

<script>
import axios from 'axios'
const lhost = 'http://localhost:8787'

export default {
  props: ["ent"],
  data: () => ({
    headers: [
      { text: 'Nome da entidade', align: 'left', sortable: true, value: 'n', class: 'title' },
      { text: 'Contratos', align: 'left', sortable: true, value: 'colaboradores', class: 'title' }
    ],
    contratos: []
  }),
  mounted: async function () {
    try {
      var response = await axios.get(lhost + '/entidades/' + this.ent)
      this.contratos = response.data
      console.log(this.contratos)
    } catch (e) {
      console.log(e)
      return (e)
    }
  },
  methods: {
    goToEntAdjudicataria: function (item) {
      this.$router.push('/contratos/' + item)
    },
    goBack: function () {
      this.$router.go(-1)
    }
  } 
}

</script>

<style>

</style>
